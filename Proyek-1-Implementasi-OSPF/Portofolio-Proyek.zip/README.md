
# Portofolio Proyek

Ini adalah portofolio proyek saya sebagai seorang Network Engineer.

## Daftar Proyek
1. [Implementasi OSPF pada MikroTik](./Proyek-1-Implementasi-OSPF/)
2. [Simulasi VLAN pada TP-Link](./Proyek-2-Simulasi-VLAN/)


# Simulasi VLAN pada TP-Link

Proyek ini bertujuan untuk memisahkan jaringan menggunakan VLAN dan memastikan komunikasi antar VLAN dengan inter-VLAN routing.

## Tools yang Digunakan
- TP-Link TL-WR840N
- Cisco Packet Tracer

## Dokumentasi
- **Diagram Jaringan VLAN:**
  ![Diagram VLAN](./diagram-vlan.png)
- **File Konfigurasi:**
  [konfigurasi-vlan.txt](./konfigurasi-vlan.txt)

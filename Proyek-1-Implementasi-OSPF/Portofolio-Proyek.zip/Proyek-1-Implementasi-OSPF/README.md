
# Implementasi OSPF pada MikroTik

Proyek ini bertujuan untuk mengimplementasikan protokol routing dinamis OSPF pada jaringan MikroTik.

## Tools yang Digunakan
- MikroTik RouterOS
- GNS3

## Dokumentasi
- **Diagram Jaringan:**
  ![Diagram Jaringan](./topologi-jaringan.png)
- **File Konfigurasi:**
  [konfigurasi-router.txt](./konfigurasi-router.txt)
